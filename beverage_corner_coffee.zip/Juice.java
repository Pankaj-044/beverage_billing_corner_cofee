class Juice{
	
	public void drink(){
		System.out.println("You got the Juice");
		System.out.println("Put straw into juice");
		System.out.println("Now drink the juice!!");
	}
}




