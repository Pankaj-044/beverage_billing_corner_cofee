class Coffee{
	
	public void drink(){
		System.out.println("You got the coffe");
		System.out.println("Take sugar and mix it as per need");
		System.out.println("Now drin the coffee!!");
	}
}




